<?php 
echo "
<html lang='ko'>
    <head>
        <meta charset='utf-8'>
        <title>학생정보 및 학점관리</title>
    </head>

    <body>
        안녕~  
    </body>

</html>";

?>